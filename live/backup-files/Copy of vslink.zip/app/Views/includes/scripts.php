<script src="<?= base_url('assets/js/jquery-3.3.1.min.js');?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
	var BASE_URL = '<?= base_url('/'); ?>';
</script>

<input type="hidden" class="txt_csrfname" name="<?= csrf_token() ?>" value="<?= csrf_hash() ?>">
<script src="<?= base_url('assets/js/modernizr-3.6.0.min.js');?>"></script>
<script src="<?= base_url('assets/js/plugins.js');?>"></script>
<script src="<?= base_url('assets/js/bootstrap.min.js');?>"></script>
<script src="<?= base_url('assets/js/wow.min.js');?>"></script>
<script src="<?= base_url('assets/js/waypoints.js');?>"></script>
<script src="<?= base_url('assets/js/nice-select.js');?>"></script>
<script src="<?= base_url('assets/js/counterup.min.js');?>"></script>
<script src="<?= base_url('assets/js/owl.min.js');?>"></script>
<script src="<?= base_url('assets/js/magnific-popup.min.js');?>"></script>
<script src="<?= base_url('assets/js/paroller.js');?>"></script>
<script src="<?= base_url('assets/js/contact.js');?>"></script>
<script src="<?= base_url('assets/js/main.js');?>"></script>