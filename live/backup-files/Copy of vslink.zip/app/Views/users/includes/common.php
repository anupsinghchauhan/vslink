<div id="confirm-modal" class="modal hide">
    <div class="modal-header">
        <h3>Delete</h3>
        <button data-dismiss="modal" class="close" type="button">×</button>
    </div>
    <div class="modal-body">
        <p>Are you sure you want to delete?</p>
        <div class="custom_content_area"></div>
    </div>
    <div class="modal-footer"> 
        <a data-dismiss="modal" class="btn btn-danger" id="delete_confirmed" href="#">Confirm</a> <a data-dismiss="modal" class="btn" href="#">Cancel</a> 
    </div>
</div>