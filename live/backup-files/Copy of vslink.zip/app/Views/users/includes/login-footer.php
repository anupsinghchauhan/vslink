<!-- jquery-->
    <script src="<?= base_url('assets/js/jquery-3.3.1.min.js');?>"></script>
    <!-- Bootstrap js -->
    <script src="<?= base_url('assets/loginpage/js/bootstrap.min.js');?>"></script>
    <!-- Imagesloaded js -->
    <script src="<?= base_url('assets/loginpage/js/imagesloaded.pkgd.min.js');?>"></script>
    <!-- Validator js -->
    <script src="<?= base_url('assets/loginpage/js/validator.min.js');?>"></script>
    <!-- Custom Js -->
    <script src="<?= base_url('assets/loginpage/js/main.js');?>"></script>