$(function(e) {

	$('#example').DataTable();

	$('#example2').DataTable();

	$('#example3').DataTable();

	$('#example4').DataTable();

	$('#example5').DataTable();

	$('#example6').DataTable();

	$('#example7').DataTable();

	$('#example8').DataTable();

	$('#example9').DataTable();

	$('#example10').DataTable();

	$('#example11').DataTable();

	$('#example12').DataTable();

	$('#example13').DataTable();

	$('#example14').DataTable();

	$('#example15').DataTable();

	$('#example16').DataTable();

	$('#example17').DataTable();

	$('#referral').DataTable({searching: false});

} );

